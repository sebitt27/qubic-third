#!/bin/bash

configJson=`echo $@ | sed 's/[^{]*//' | sed 's/[^}]*$//'`
configParms=`echo $@ | awk -F"{" '{ print $1 }'`

if [[ ! -z ${configJson} ]]; then
  echo "Generating miner config..."
  mv appsettings.json appsettings.json.org
  echo "${configJson}" > appsettings.json
fi

LD_LIBRARY_PATH=$LD_LIBRARY_PATH:./; export LD_LIBRARY_PATH;
./qli-Client ${configParms}
