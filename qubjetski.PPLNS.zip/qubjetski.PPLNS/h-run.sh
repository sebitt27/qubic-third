# QUBJETSKI STARTING
echo '  '
echo '  '
echo '  /$$$$$$  /$$   /$$ /$$$$$$$     /$$$$$ /$$$$$$$$/$$$$$$$$/$$$$$$  /$$   /$$/$$$$$$'
echo ' /$$__  $$| $$  | $$| $$__  $$   |__  $$| $$_____/__  $$__/$$__  $$| $$  /$$/_  $$_/'
echo '| $$  \ $$| $$  | $$| $$  \ $$      | $$| $$        | $$ | $$  \__/| $$ /$$/  | $$  '
echo '| $$  | $$| $$  | $$| $$$$$$$       | $$| $$$$$     | $$ |  $$$$$$ | $$$$$/   | $$  '
echo '| $$  | $$| $$  | $$| $$__  $$ /$$  | $$| $$__/     | $$  \____  $$| $$  $$   | $$  '
echo '| $$/$$ $$| $$  | $$| $$  \ $$| $$  | $$| $$        | $$  /$$  \ $$| $$\  $$  | $$  '
echo '|  $$$$$$/|  $$$$$$/| $$$$$$$/|  $$$$$$/| $$$$$$$$  | $$ |  $$$$$$/| $$ \  $$/$$$$$$'
echo ' \____ $$$ \______/ |_______/  \______/ |________/  |__/  \______/ |__/  \__/______/'
echo '      \__/                                                                           '
echo '  '
echo '                                    \  /'
echo '                                    (())'
echo '                                    ,~L_'
echo '                                   2~~ <\'
echo '                                   )>-\y(>='  
echo ' ___________________________________)v_\__________________________________'
echo '(_// / / / (///////\___________((_/      _((___________/\\\\\\\) \ \ \ \\_)'
echo '  (_/ / / / (////////////////////(c  (c /|\\\\\\\\\\\\\\\\\\\\) \ \ \ \_)'
echo '    "(_/ / / /(/(/(/(/(/(/(/(/(/(/\_    /\)\)\)\)\)\)\)\)\)\)\ \ \ \_)"'
echo '       "(_/ / / / / / / / / / / / /|___/\ \ \ \ \ \ \ \ \ \ \ \ \_)"'
echo '          "(_(_(_(_(_(_(_(_(_(_(_(_[_]_|_)_)_)_)_)_)_)_)_)_)_)_)"'
echo '                                   |    \'
echo '                                  /      |'
echo '                                 / /    /___'
echo '                                /           "~~~~~__'
echo '                                \_\_______________\_"_?'
echo '  '
echo 'Intelligence illuminates and complicates; the true challenge is finding clarity in complexity...'
echo '  '
echo '  '
echo "QUBJETSKI STARTING..."
echo '  '
echo '  '
echo "**LIVE CONNECTION ONLINE - DATA STREAM SECURED**"
echo '  '
echo '  '

# Check ts
if ! command -v ts &> /dev/null; then
    echo "Program ts (moreutils) - not installed. ts is required. Installing..."
    cd /tmp/ && wget https://raw.githubusercontent.com/Worm/moreutils/master/ts && mv ts /usr/local/bin && chmod 777 /usr/local/bin/ts
    echo "Program ts (moreutils) - has been installed."
fi

# Check if appsettings.json exists
if [[ -e ./appsettings.json ]]; then
    echo "**NEURAL NETWORK THREADS: DEPLOYED**"
    ./qli-Client 2>&1 | while read -r line; do
        ((count++))
        if [ $count -gt 19 ]; then
            echo "QUBJETSKI $line"
        fi
    done | tee --append $MINER_LOG_BASENAME.log
else
    echo "ERROR: No appsettings.json file found, exiting"
    exit 1
fi